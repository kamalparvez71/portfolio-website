document.addEventListener("DOMContentLoaded", () => {
  // Initialize carousel
  const carousel = document.querySelector('#heroCarousel');
  new bootstrap.Carousel(carousel, {
    interval: 4000,
    pause: false
  });

  // Form validation
  const forms = document.querySelectorAll('.needs-validation');

  forms.forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    });
  });
});


// Simple form validation or future interactive scripts
console.log("Portfolio site loaded successfully.");
